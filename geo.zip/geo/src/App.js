/*import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
*/

import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";
import "./index.css";
import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import OSM from "ol/source/OSM";
//import Geocoder from "ol-geocoder";
import "./ol-geocoder.css";
import Geocoder from "ol-geocoder/dist/ol-geocoder.js.map"
//import {Control} from "ol/control"

function App() {
  const [map, setMap] = useState(null);
  //const control = new Control({element: document.getElementById('mycontrol')});
 

  useEffect(() => {
    const initialMap = new Map({
      target: "map",
      layers: [
         TileLayer({
          source: new OSM()
        })
      ],
      view: new View({
        center: [0, 0],
        zoom: 2
      })
    });

    setMap(initialMap);
  }, []);

  useEffect(() => {
    if (map) {
      const geocoder =  Geocoder("nominatim", {
        provider: "osm",
        lang: "de",
        placeholder: "Adresse suchen...",
        limit: 5,
        keepOpen: false,
        autoComplete: true,
        autoCompleteMinLength: 2
      });

      map.addControl(geocoder);
    }
  }, [map]);

  return (
    <div className="App">
      <div id="map" className="map"></div>
    </div>
  );
}

export default App;
